#ifndef __EXTERNAL_IP_H
#define __EXTERNAL_IP_H

void getExternalIP();

extern char externalIP[16];

#endif
