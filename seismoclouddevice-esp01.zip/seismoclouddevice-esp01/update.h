
#ifndef __UPDATE_H
#define __UPDATE_H

void checkForUpdates();

#endif
